import java.util.Scanner;
import java.util.ArrayList;
public class hangMan {
	public String handle(String guess, ArrayList<String> word, ArrayList<String> Display) {
		//changes all letters matching to that letter ___ -> b_b when the word is "bob" and the guess is 'b'
		for(int i = 0; i < word.size(); i++) {
			if (word.get(i).equals(guess)) {
				Display.set(i, guess);
			}
		}
		//converting arraylist into string to return
		String ret = "";
		for(int i2 = 0; i2 < Display.size(); i2++) {
			ret += Display.get(i2);
		}
		return ret;
	}
	public ArrayList<String> toList(String word){
		ArrayList<String> ret = new ArrayList<String>();
		for(int i = 0; i < word.length(); i++) {
			ret.add(Character.toString(word.charAt(i)));
		}
		return ret;
	}
	public ArrayList<String> hide(ArrayList<String> held){
		ArrayList<String> ret = new ArrayList<String>();
		for(int i = 0; i < held.size(); i++) {
			if (held.get(i) != " ") {
				ret.add("_");
			}else {
				ret.add(" ");
			}
		}
		return ret;
	}
	public String toString(ArrayList<String> list) {
		String ret = "";
		for(int i = 0; i < list.size(); i++) {
			ret += list.get(i);
		}
		return ret;
	}
	public boolean check(ArrayList<String> Guessed, String guess) {
		boolean ret = false;
		String[] Alphabet = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
		for(int i = 0; i < Guessed.size(); i++) {
			if (Guessed.get(i).equals(guess)) {
				ret = true;
			}
		}
		if(guess != "") {
			boolean test = true;
			for(int i = 0; i < Alphabet.length; i++) {
				if(Alphabet[i] == guess) {
					test = false;
				}
			}
			if(!test) {
				ret = true;
			}
		}
		if(guess.length() > 1) {
			ret = true;
		}
		return ret;
	}
	public boolean ifFalse(String word, String theCurrent){
		if(word.equals(theCurrent)) {
			return true;
		}else {
			return false;
		}
	}
	public String returnRandom() {
		String[] ret = {"apple", "banana", "orange", "grape", "strawberry", "watermelon", "pineapple",
			    "apricot", "peach", "pear", "plum", "cherry", "blueberry", "raspberry", "blackberry",
			    "kiwi", "lemon", "lime", "mango", "papaya", "coconut", "fig", "nectarine", "date",
			    "avocado", "guava", "cantaloupe", "honeydew", "pomegranate", "cranberry", "elderberry",
			    "grapefruit", "kumquat", "lychee", "passionfruit", "persimmon", "quince", "tangerine",
			    "boysenberry", "rhubarb", "mulberry", "jackfruit", "starfruit", "durian", "acai",
			    "plantain", "soursop", "breadfruit", "ackee", "salak", "pawpaw", "ugli", "longan",
			    "cherimoya", "custard apple"};
		String retWord = ret[(int) (Math.random() * ret.length) + 1];
		return retWord;
	}
	public static void main(String[] args) {
		int counter = 0;
		hangMan obj = new hangMan();
		Scanner input = new Scanner(System.in);
		String chosenWord = obj.returnRandom();
		ArrayList<String> word = obj.toList(chosenWord);
		ArrayList<String> Display = obj.hide(word);
		ArrayList<String> Guessed = new ArrayList<String>();
		System.out.println("Current Progress: "+obj.toString(Display));
		System.out.print("What is your guess?: ");
		String guess = input.nextLine();
		String Displayed = obj.handle(guess, word, Display);
		String lastWord = obj.toString(obj.hide(word));
		if(obj.ifFalse(lastWord, Displayed)) {
			counter++;
		}
		Guessed.add(guess);
		System.out.println("Current Progress: "+Displayed);
		//game loop
		boolean gameOn = true;
		while (gameOn) {
			if(obj.toString(Display).equals(chosenWord)) {
				System.out.println("You Win");
				gameOn = false;
				
			}else if(counter >= 6){
				System.out.println("You Lose");
				gameOn = false;
				
			}else {
				System.out.print("What is your next guess?: ");
				guess = input.nextLine();
				while (obj.check(Guessed, guess)) {
					System.out.println("You already guessed that one.");
					System.out.print("What is your next guess?: ");
					guess = input.nextLine();
				}
				lastWord = obj.toString(Display);
				Displayed = obj.handle(guess, word, Display);
				if(obj.ifFalse(lastWord, Displayed)) {
					counter++;
				}
				Guessed.add(guess);
				System.out.println("Current Progess: "+Displayed);
			}
		}
	}

}