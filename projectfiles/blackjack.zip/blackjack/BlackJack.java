package calc;
import java.util.ArrayList;
import java.util.Scanner;

public final class BlackJack {
	
	public int basicTotalValue(ArrayList<card> hand) {
		int ret = 0;
		for(int i = 0; i < hand.size(); i++) {
			if(hand.get(i).getValue() > 10) {
				ret += 10;
			}else {
				ret += hand.get(i).getValue();
			}
		}
		return ret;
	}
	
	public boolean containsAce(ArrayList<card> hand) {
		boolean ret = false;
		for(int i = 0; i < hand.size(); i++) {
			if(hand.get(i).isAce()) {
				ret = true;
			}
		}
		return ret;
	}
	
	public int totalValue(ArrayList<card> hand) {
		if(basicTotalValue(hand) > 21 && containsAce(hand)) {
			for(int i = 0; i < hand.size(); i++) {
				if(hand.get(i).isAce()) {
					hand.get(i).changeValue(1);
				}
			}
		}
		return basicTotalValue(hand);
	}
	
	public String displayHand(ArrayList<card> hand) {
	    String ret = "";
	    for(int i = 0; i < hand.size(); i++) {
	        ret += hand.get(i).getStringValue() + " of " + hand.get(i).getSymbol();
	        if (i < hand.size() - 1) {
	            ret += ", ";
	        }
	    }
	    return ret;
	}
	
	public String displayCard(card hand) {
		String ret = "";
		ret += hand.getStringValue()+" of "+hand.getSymbol();
		return ret;
	}
	
	//
	public void calcWin(ArrayList<card> hand, ArrayList<card> dealerhand, deck possibleCards) {
		ArrayList<Integer> combinations = new ArrayList<Integer>();
		ArrayList<card> test = new ArrayList<card>(hand);
		//the numbers are num times lost, num times 21, and num times not losing
		ArrayList<Integer> possibleOutcomes = new ArrayList<Integer>();
		//initializing and setting all the values to 0
		possibleOutcomes.add(0);
		possibleOutcomes.add(0);
		possibleOutcomes.add(0);
		ArrayList<card> possible = possibleCards.getDeck();
		possible.add(dealerhand.get(1));
		// checking the outcomes of all the combination
		for(int i = 0; i < possible.size(); i++) {
			test.add(possible.get(i));
			combinations.add(totalValue(test));
			test = new ArrayList<card>(hand);
		}
		//this part counts all the outcomes
		for(int i = 0; i < combinations.size(); i++) {
			if(combinations.get(i) > 21) {
				possibleOutcomes.set(0, possibleOutcomes.get(0)+1);
			}else if(combinations.get(i) == 21) {
				possibleOutcomes.set(1, possibleOutcomes.get(1)+1);
			}else {
				possibleOutcomes.set(2, possibleOutcomes.get(2)+1);
			}
		}
		double sum = possibleOutcomes.get(0) + possibleOutcomes.get(1) + possibleOutcomes.get(2);
		System.out.println("=====================================");
		System.out.println("Chance of Busting: "+ 100*((double)possibleOutcomes.get(0)/sum) + "%");
		System.out.println("Chance of Getting 21: "+ 100*((double)possibleOutcomes.get(1)/sum) + "%");
		System.out.println("Chance of Not Busting: "+ 100*((double)possibleOutcomes.get(2)/sum) + "%");
		System.out.println("=====================================");
		System.out.println(" ");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BlackJack obj = new BlackJack();
		Scanner input = new Scanner(System.in);
		deck gameDeck = new deck();
		ArrayList<card> playerHand = new ArrayList<card>();
		ArrayList<card> dealerHand = new ArrayList<card>();
		//drawing cards for the players
		dealerHand.add(gameDeck.drawCard());
		dealerHand.add(gameDeck.drawCard());
		
		while(obj.totalValue(dealerHand) == 21) {
			gameDeck.shuffle();
			dealerHand = new ArrayList<card>();
			dealerHand.add(gameDeck.drawCard());
			dealerHand.add(gameDeck.drawCard());
		}
		
		playerHand.add(gameDeck.drawCard());
		playerHand.add(gameDeck.drawCard());
		
		boolean gameOn = true;
		
		ArrayList<card> possibleCards = gameDeck.getDeck();
		possibleCards.add(dealerHand.get(1));
		
		//game handler
		while(gameOn) {
			System.out.println("Dealer's Shown Card: "+dealerHand.get(0).getStringValue()+" of "+dealerHand.get(0).getSymbol());
			System.out.println("Your Cards: "+obj.displayHand(playerHand));
			System.out.println("Total Value: "+ obj.totalValue(playerHand));
			//next is just play inputs
			obj.calcWin(playerHand, dealerHand, gameDeck);
			System.out.print("Hit? (y/n): ");;
			String playerAction = input.nextLine();
			System.out.println("");
			if (playerAction.toLowerCase().equals("y")) {
				card drawnCard = gameDeck.drawCard();
				System.out.println(obj.displayCard(drawnCard));
				playerHand.add(drawnCard);
			}else {
				gameOn = false;
				while(obj.totalValue(dealerHand) < 17) {
					dealerHand.add(gameDeck.drawCard());
				}
			}
			if (obj.totalValue(playerHand) > 21) {
				gameOn = false;
			}
		}
		if(obj.totalValue(dealerHand) > 21 && obj.totalValue(playerHand) < 22 || obj.totalValue(playerHand) > obj.totalValue(dealerHand) && obj.totalValue(playerHand) <= 21) {
			
			System.out.println("===================================================");
			System.out.println("Dealer's Hand: " + obj.displayHand(dealerHand));
			System.out.println("Dealer's Value: "+obj.totalValue(dealerHand));
			System.out.println("Player's Hand: " + obj.displayHand(playerHand));
			System.out.println("Player's Value: "+obj.totalValue(playerHand));
			System.out.println("\nPLayer Wins");
			
		}else if(obj.totalValue(playerHand) > 21 && obj.totalValue(dealerHand) < 22 || obj.totalValue(playerHand) < obj.totalValue(dealerHand) && obj.totalValue(dealerHand) <= 21) {
			
			System.out.println("===================================================");
			System.out.println("Dealer's Hand: " + obj.displayHand(dealerHand));
			System.out.println("Dealer's Value: "+obj.totalValue(dealerHand));
			System.out.println("Player's Hand: " + obj.displayHand(playerHand));
			System.out.println("Player's Value: "+obj.totalValue(playerHand));
			System.out.println("\nDealer Wins");
			
		}else {
			
			System.out.println("===================================================");
			System.out.println("Dealer's Hand: " + obj.displayHand(dealerHand));
			System.out.println("Dealer's Value: "+obj.totalValue(dealerHand));
			System.out.println("Player's Hand: " + obj.displayHand(playerHand));
			System.out.println("Player's Value: "+obj.totalValue(playerHand));
			System.out.println("\nTie");
			
		}
	}

}
