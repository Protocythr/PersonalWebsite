package calc;

public class card {
	private int value;
	private String symbol;
	private int symbolValue;
	private boolean ace = false;
	// constructor
	public card() {
		value = (int)(1+Math.random()*13);
		symbolValue = (int)(1+Math.random()*4);
		if(symbolValue == 1) {
			symbol = "Diamonds";
		}else if(symbolValue == 2) {
			symbol = "Clubs";
		}else if(symbolValue == 3) {
			symbol = "Hearts";
		}else if(symbolValue == 4) {
			symbol = "Spades";
		}
		if (value == 1) {
			this.value = 11;
			ace = true;
		}
	}
	public card(int value, int symbolValue) {
		this.value = value;
		this.symbolValue = symbolValue;
		if(symbolValue == 1) {
			symbol = "Diamonds";
		}else if(symbolValue == 2) {
			symbol = "Clubs";
		}else if(symbolValue == 3) {
			symbol = "Hearts";
		}else if(symbolValue == 4) {
			symbol = "Spades";
		}
		if (value == 1) {
			this.value = 11;
			ace = true;
		}
	}
	//accessor methods
	public String getSymbol() {
		return symbol;
	}
	public String getStringValue() {
		if (value == 11 && !ace) {
			return "Jack";
		}else if (value == 12) {
			return "Queen";
		}else if (value == 13){
			return "King";
		}else if (value == 11 && ace) {
			return "Ace";
		}else if (value == 1) {
			return "Ace";
		}
		return Integer.toString(value);
	}
	public int getSymbolValue() {
		return symbolValue;
	}
	public int getValue() {
		return value;
	}
	public boolean isAce() {
		return ace;
	}
	public void changeValue(int value) {
		this.value = value;
	}
}
