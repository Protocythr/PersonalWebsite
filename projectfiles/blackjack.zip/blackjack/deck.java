package calc;
import java.util.ArrayList;

public class deck {
	ArrayList<card> deck = new ArrayList<card>();
	public deck() {
		for(int i = 0; i < 52; i++) {
			deck.add(new card(1+(i%13), (int)(1+(i/13))));
		}
	}
	public ArrayList<card> getDeck(){
		return deck;
	}
	public card drawCard() {
		int index = (int)(Math.random()*deck.size());
		card ret = deck.get(index);
		deck.remove(index);
		return ret;
	}
	public void shuffle() {
		deck = new ArrayList<card>();
		for(int i = 0; i < 52; i++) {
			deck.add(new card(1+(i%13), (int)(1+(i/13))));
		}
	}
}
