package calc;
import java.util.Scanner;

public class tic_tac_toe {
	//checks if a space is taken and asks the player to change
	public int[][] handler(int x, int y, int player, int[][] board) {
		Scanner input = new Scanner(System.in);
		while(board[x][y] != 9) {
			System.out.println("Space Taken By Another Player");
			System.out.print("Please pick another y-value: ");
			x = Integer.parseInt(input.nextLine());
			System.out.print("Please pick another x-value: ");
			y = Integer.parseInt(input.nextLine());
		}
		board[x][y] = player;
		return board;
	}
	public boolean checkWin(int[][] board) {
		boolean ret = false;
		for(int i = 0; i < board[0].length; i++) {
			//checks for horizontal wins and vertical wins
			if(board[i][0] + board[i][1] + board[i][2] == 3 || board[i][0] + board[i][1] + board[i][2] == 6) {
				ret = true;
			}
			if(board[0][i] + board[1][i] + board[2][i] == 3 || board[0][i] + board[1][i] + board[2][i] == 6) {
				ret = true;
			}
		}
		//this checks for diagonal wins
		if(board[0][0] + board[1][1] + board[2][2] == 3 || board[0][0] + board[1][1] + board[2][2] == 6) {
			ret = true;
		}
		if(board[0][2] + board[1][1] + board[2][0] == 3 || board[0][2] + board[1][1] + board[2][0] == 6) {
			ret = true;
		}
		return ret;
	}
	//goes line by line and displays each value
	public void displayBoard(int[][] board) {
		for(int x = 0; x < board[0].length; x++) {
			for(int y = 0; y < board.length; y++) {
				if(board[x][y] != 9) {
					if(board[x][y] == 1) {
						System.out.print("X");
					}else if (board[x][y] == 2) {
						System.out.print("O");
					}
				}else {
					System.out.print(0);
				}
			}
			System.out.println("");
		}
	}
	public String play(int startingPlayer, int[][] board ) {
		//declaring variables
		Scanner input = new Scanner(System.in);
		boolean gameOn = true;
		int currentplayer = startingPlayer;
		int rounds = 0;
		while (gameOn) {
			displayBoard(board);
			System.out.println("Player"+currentplayer);
			System.out.print("Please pick a y-value: ");
			int x = Integer.parseInt(input.nextLine());
			System.out.print("Please pick a x-value: ");
			int y = Integer.parseInt(input.nextLine());
			board = handler(x, y, currentplayer, board);
			if(checkWin(board)) {
				gameOn=false;
			}
			if(gameOn) {
				if(currentplayer == 1) {
					currentplayer = 2;
				}else {
					currentplayer = 1;
				}
			}
			if(rounds == 9) {
				gameOn = false;
				if(!checkWin(board)) {
					return "No One";
				}
			}
			rounds++;
		}
		return ("Player"+currentplayer);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		tic_tac_toe obj = new tic_tac_toe();
		int playerturn = 1; 
		int[][] board = {{9,9,9},
						 {9,9,9},
						 {9,9,9}};
		System.out.println("Winner: "+obj.play(playerturn
				+, board));
		
	}

}
